<?php
/**
 * Single Product Image
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.6.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post, $product;
?>
<div class="col-md-9">
	<div class="row">
		<div class="col-md-5 slider-product-img">
				<?php
				if ( has_post_thumbnail() ) {
					$attachment_count = count( $product->get_gallery_attachment_ids() );
					$gallery          = $attachment_count > 0 ? '[product-gallery]' : '';
					$props            = wc_get_product_attachment_props( get_post_thumbnail_id(), $post );
					$image            = get_the_post_thumbnail( $post->ID, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ), array(
						'title'	 => $props['title'],
						'alt'    => $props['alt'],
					) );
					echo apply_filters(
						'woocommerce_single_product_image_html',
						sprintf(
							'<a href="%s" itemprop="image" class="woocommerce-main-image zoom" title="%s" data-rel="prettyPhoto%s">%s</a>',
							esc_url( $props['url'] ),
							esc_attr( $props['caption'] ),
							$gallery,
							$image
						),
						$post->ID
					);
				} else {
					echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" alt="%s" />', wc_placeholder_img_src(), __( 'Placeholder', 'woocommerce' ) ), $post->ID );
				}

				do_action( 'woocommerce_product_thumbnails' );
			?>
		</div>
		<div class="col-md-7 detail-product">
			<?php
			woocommerce_template_single_title();
			echo set_countdown($post->ID);
			woocommerce_template_single_rating();
			woocommerce_template_single_price();?>
			<?php
			global $product;
			$formatted_attributes = array();
			$attributes = $product->get_attributes();
			foreach($attributes as $attr=>$attr_deets){
			    $attribute_label = wc_attribute_label($attr);
			    if ( isset( $attributes[ $attr ] ) || isset( $attributes[ 'pa_' . $attr ] ) ) {
			        $attribute = isset( $attributes[ $attr ] ) ? $attributes[ $attr ] : $attributes[ 'pa_' . $attr ];
			        if ( $attribute['is_taxonomy'] ) {
			            $formatted_attributes[$attribute_label] = implode( ', ', wc_get_product_terms( $product->id, $attribute['name'], array( 'fields' => 'names' ) ) );
			        } else {
			            $formatted_attributes[$attribute_label] = $attribute['value'];
			        }
			    }
			}
			foreach($formatted_attributes as $k => $vl) :
				echo '	<div class="product-attribute">
			 				'.$k.': <span>'.$vl.'</span>
			 			</div>';
			endforeach;
			
	        $khuyen_mai = get_post_meta( $post->ID, 'khuyen_mai', true );
	        if(!empty($khuyen_mai)){?>
		        <div itemprop="description">
		        	<fieldset>
						<legend>KHUYẾN MÃI</legend>
						<?php echo $khuyen_mai;?>
					</fieldset>
				</div>
	        <?php }else{?>
				<div itemprop="description">
					<?php the_excerpt(); ?>
				</div>
	        <?php }

				woocommerce_template_single_add_to_cart();
				woocommerce_template_single_meta();
				woocommerce_template_single_sharing();

				/**
				 * woocommerce_single_product_summary hook
				 *
				 * @hooked woocommerce_template_single_title - 5
				 * @hooked woocommerce_template_single_rating - 10
				 * @hooked woocommerce_template_single_price - 10
				 * @hooked woocommerce_template_single_excerpt - 20
				 * @hooked woocommerce_template_single_add_to_cart - 30
				 * @hooked woocommerce_template_single_meta - 40
				 * @hooked woocommerce_template_single_sharing - 50
				 */
				//do_action( 'woocommerce_single_product_summary' );
			?>
		</div>
	</div>
</div>